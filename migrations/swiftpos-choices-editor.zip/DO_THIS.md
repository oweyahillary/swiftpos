# Choices & upgrades — editable (for `dev`)

8 files. Includes migration 45 for reference; you have already run it.

```bash
cd apps/server && npm run build        # deploy — the PATCH endpoint changed
cd apps/desktop
npm version 0.4.2 --no-git-tag-version
npx tsc -p tsconfig.json && npx tsc -p tsconfig.main.json && npx vite build \
  && rm -rf release && npm run pack:installer && npm run pack:portable
```

Server deploy is required: `PATCH /api/variants/groups/:id` could not set `kind`
before, so the editor would silently do nothing without it.

---

## What is new

**Menu → select an item → Choices & upgrades.** Each group now shows what it IS
and lets you change it:

- **Choice** — free preference. No price box at all, just "free". A price here is
  a category error, not a valid value, and an input showing 0 invites someone to
  type in it.
- **Upgrade** — priced ladder, with an editable amount per option.

**A "Review" filter** on the item list, with a count, plus an amber badge on each
affected item. It scans every product's groups on load, because an unresolved
group nobody looks at stays unresolved forever.

## Two guards worth knowing

**Switching a group to Choice zeroes its prices — on the server, not the client.**
Otherwise "a choice never changes the price" is false the moment someone relabels
a priced group from a different screen. Verified: switching Ugali to Choice zeroes
all three amounts and keeps the option names.

**An upgrade with no zero-priced option is flagged against the item.** That is
Cake / Size today: `Large +50`, `medium +20`, nothing at 0. It works only because
the group is optional — make it required and every cake costs +20 minimum.
Verified numerically.

## What I fixed while in there

`PATCH /api/variants/groups/:id` destructured `{ name, required }` and updated both
unconditionally. It survived only because supabase-js drops `undefined` during
serialisation — so patching just the name relied on that to avoid clearing
`required`. One JSON-shape change from wiping a field nobody edited. It now builds
the patch from the keys actually sent.

## Try it

1. Menu → **Review** filter. Should show 2 items — 3PC Chicken and Cake.
2. Open Cake → its Size group is amber, with the missing-baseline warning.
3. Open 3PC Chicken → the Spice group should already read **Choice** (free),
   and Size should be amber.
4. Set Cake's Size to **Upgrade**, then set one option to 0 — the warning clears.

## What I still cannot do for you

`3PC Chicken / Size` mixes a fries upgrade (+60) and a drink upgrade (+50) in one
list. Splitting it into two groups scoped to two different components needs the
component-scoping UI, which is the next piece. For now it is visible and flagged
rather than silently wrong.
